=== Reset WP ===
Contributors: Nikunj Soni
Donate link: http://www.nikunjsoni.co.in/donate
Tags: reset wp,reset-wp,reset,wp,wordpress,clean,cleaner,database,mysql,wp-admin,admin,plugin
License: GPLv2
Requires at least: 3.7
Tested up to: 4.4
Stable tag: 1.0

Resets the WP Database to the default installation. It deletes all content and custom changes. Resets only database not modify or delete any files.

== Description ==

It resets the WordPress database to the default installation. It deletes all content and custom changes. It will only reset the database. It will not modify or delete any files.

* It adds a settings page to "Dashboard"->"Tools"->"Reset WP" where you can simply reset your WordPress database.
* It adds submenu to the Admin Bar under the site title for quick access of this plugin.
* Resets WordPress in quick time.
* Handy tool for WordPress Programmers to reset database.

Usage :

1. Download and extract this plugin to `wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. "Dashboard"->"Tools"->"Reset WP"

== Installation ==

1. Download and extract this plugin to `wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. "Dashboard"->"Tools"->"Reset WP"

== Screenshots ==

1. Admin page screenshot
2. Admin page screenshot for reset confirmation.
3. Admin page screenshot for reset confirmation.

== Other Notes ==

Usage :

1. Download and extract this plugin to `wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. "Dashboard"->"Tools"->"Reset WP"

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
* Initial release.

== Frequently Asked Questions ==

You can submit it in http://www.nikunjsoni.co.in